public class BBM {
    String namaBBM;
    double hargaPerLiter;

    BBM(String namaBBM, double harga) {
        this.namaBBM = namaBBM;
        this.hargaPerLiter = harga;
    }
}